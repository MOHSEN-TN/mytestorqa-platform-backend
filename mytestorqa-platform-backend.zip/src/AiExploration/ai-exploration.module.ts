import { Module } from '@nestjs/common';
import { AIExplorationController } from './ai-exploration.controller';
import { AIExplorationService } from './ai-exploration.service';
import { PrismaModule } from '../prisma/prisma.module';

@Module({
  imports: [PrismaModule],
  controllers: [AIExplorationController],
  providers: [AIExplorationService],
  exports: [AIExplorationService],
})
export class AIExplorationModule {}